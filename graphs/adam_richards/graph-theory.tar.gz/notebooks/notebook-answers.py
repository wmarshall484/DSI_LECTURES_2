#!/usr/bin/env python


import networkx as nx
import matplotlib.pyplot as plt

def draw_network(edge_dict,file_name=None,ax=None,node_size=300):
    """draw a simple network"""
    if not ax:
        fig = plt.figure()
        ax = fig.add_subplot(111)
        ax.set_yticks([])
        ax.set_xticks([])

    G = nx.Graph()
    for edge,weight in edge_dict.items():
        G.add_edge(edge[0],edge[1],weight=weight)

    pos=nx.spring_layout(G)

    ## draw the nodes                                                                                                          
    nx.draw_networkx(G,pos,node_size=node_size,
                     node_color='#ADD8E6',alpha=0.9,ax=ax)

    if file_name:
        plt.savefig(file_name)

fig = plt.figure(figsize=(10,8))
ax1 = fig.add_subplot(1,2,1,aspect='equal')
ax2 = fig.add_subplot(1,2,2)

#G1=nx.erdos_renyi_graph(100,0.15)
#G1=nx.watts_strogatz_graph(30,3,0.1)
G1=nx.barabasi_albert_graph(100,5)
G2=nx.random_lobster(100,0.9,0.9)
print(dir(G1))
print(G1.__repr__)
#print(G1.__doc__)

edge_dict1 = dict([(e, 1) for e in G1.edges()])
edge_dict2 = dict([(e, 1) for e in G2.edges()])
draw_network(edge_dict1,file_name=None,ax=ax1,node_size=200)
draw_network(edge_dict2,file_name="path.png",ax=ax2,node_size=200)

for ax in [ax1,ax2]:
    ax.set_aspect(1./ax.get_data_ratio())

plt.show()

